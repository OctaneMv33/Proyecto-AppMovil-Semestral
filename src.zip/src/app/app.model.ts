export interface User{
    id: number;
    usuario: string;
    contrasena: string;
}